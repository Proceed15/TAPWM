﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TAPWM_EmpregadoClasses_Aula1
{
    internal class Mensalista : Empregado
    {
        public Mensalista(int matx, string nomex, DateTime datax, double salx)
        {
            this.Matricula = matx;
            this.NomeEmpregado = nomex;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salx;
        }
        public Mensalista() {
            
        }
        public double SalarioMensal { get; set; }


        public static String Empresa = "Tesla";
        public const String Filial = "Filial Brasil";

        public override double SalarioBruto()
        {
            return SalarioMensal;
        }
    }
}
